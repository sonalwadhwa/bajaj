package com.chitkara.bajaj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
