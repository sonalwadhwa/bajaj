package com.chitkara.bajaj.entities;

public class Alphabets {
    private String alphabets;
    public Alphabets(String alphabets) {
        this.alphabets = alphabets;
    }
    @Override
    public String toString() {
        return "Alphabets{" +
                "alphabets='" + alphabets + '\'' +
                '}';
    }


    public String getAlphabets() {
        return alphabets;
    }
    public void setAlphabets(String alphabets) {
        this.alphabets = alphabets;
    }


}
