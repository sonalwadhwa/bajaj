package com.chitkara.bajaj.service;

import com.chitkara.bajaj.entities.Entities;

import java.util.List;

public interface BajajService {
    public List<Entities> getEntities();
}
