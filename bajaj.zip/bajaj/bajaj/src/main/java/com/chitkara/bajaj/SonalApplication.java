package com.chitkara.bajaj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SonalApplication.class, args);
	}

}
