package com.chitkara.bajaj.service;

import com.chitkara.bajaj.entities.Alphabets;
import com.chitkara.bajaj.entities.ArrEntity;
import com.chitkara.bajaj.entities.Entities;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BajajServiceImpl implements BajajService{

    ArrEntity arrEntity;
    Alphabets alphabets;
    List<Entities> l1;

    public BajajServiceImpl()
    {
        l1 = new ArrayList<>();
        l1.add(new Entities(1,"True","abc@k.com","123",arrEntity = new ArrEntity("1111"),alphabets = new Alphabets("ABCD")));
        l1.add(new Entities(2,"True","abty@k.com","6576", arrEntity=new ArrEntity("2222"),alphabets=new Alphabets("klmn")));
        l1.add(new Entities(3,"True","bc@k.com","6786",arrEntity=new ArrEntity("56756"),alphabets=new Alphabets("fghf")));
        l1.add(new Entities(4,"True","tytuc@k.com","3453", arrEntity=new ArrEntity("3456576"),alphabets=new Alphabets("fdgfh")));
        l1.add(new Entities(5,"True","dfgfgh@k.com","4345", arrEntity=new ArrEntity("4342"),alphabets=new Alphabets("dfgds")));


    }
    @Override
    public List<Entities> getEntities() {
        return l1;
    }
}
