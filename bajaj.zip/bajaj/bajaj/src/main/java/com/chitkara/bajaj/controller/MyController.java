package com.chitkara.bajaj.controller;

import com.chitkara.bajaj.entities.Entities;
import com.chitkara.bajaj.service.BajajService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MyController {

    @Autowired
    private BajajService bserv;


    @GetMapping("/status")
    public String Status()
    {
        System.out.println("hello");
        return "PASS";
    }

    @GetMapping("/add")
    public List<Entities> getEntities()
    {
        return this.bserv.getEntities();
    }

}
