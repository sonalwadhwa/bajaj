package com.chitkara.bajaj.entities;

public class Entities {


    private int userId;
    private String status;
    private String email;
    private String rollno;
    private ArrEntity arrEntity;
    private Alphabets alphabets;

    public Entities(int userId, String status, String email, String rollno, ArrEntity arrEntity, Alphabets alphabets) {
        super();
        this.userId = userId;
        this.status = status;
        this.email = email;
        this.rollno = rollno;
        this.arrEntity = arrEntity;
        this.alphabets = alphabets;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public ArrEntity getArrEntity() {
        return arrEntity;
    }

    public void setArrEntity(ArrEntity arrEntity) {
        this.arrEntity = arrEntity;
    }

    public Alphabets getAlphabets() {
        return alphabets;
    }

    public void setAlphabets(Alphabets alphabets) {
        this.alphabets = alphabets;
    }

    @Override
    public String toString() {
        return "Entities{" +
                "userId=" + userId +
                ", status='" + status + '\'' +
                ", email='" + email + '\'' +
                ", rollno='" + rollno + '\'' +
                ", arrEntity=" + arrEntity +
                ", alphabets=" + alphabets +
                '}';
    }



}
